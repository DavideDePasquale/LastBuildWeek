package com.epicode.LastBuildWeek.enumeration;

public enum AddressType {
    SEDE_LEGALE,
    SEDE_OPERATIVA
}
