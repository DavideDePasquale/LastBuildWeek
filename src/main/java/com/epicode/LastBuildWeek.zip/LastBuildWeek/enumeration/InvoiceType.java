package com.epicode.LastBuildWeek.enumeration;

public enum InvoiceType {
    IN_SOSPESO,
    PAGATA
}
