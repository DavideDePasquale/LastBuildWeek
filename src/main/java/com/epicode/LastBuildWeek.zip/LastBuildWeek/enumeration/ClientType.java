package com.epicode.LastBuildWeek.enumeration;

public enum ClientType {
    PA,
    SAS,
    SPA,
    SRL
}
