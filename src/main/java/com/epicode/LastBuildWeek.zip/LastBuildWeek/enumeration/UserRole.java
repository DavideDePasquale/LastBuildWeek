package com.epicode.LastBuildWeek.enumeration;

public enum UserRole {
    ADMIN,
    USER
}
