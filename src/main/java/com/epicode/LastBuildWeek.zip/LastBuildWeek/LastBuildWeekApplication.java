package com.epicode.LastBuildWeek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LastBuildWeekApplication {

	public static void main(String[] args) {
		SpringApplication.run(LastBuildWeekApplication.class, args);
	}

}
